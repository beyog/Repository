-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE GetProductByID
	@ProductID INT
AS
BEGIN
	SET NOCOUNT ON;

    SELECT [ProductID]
      ,[CategoryID]
      ,[ProductName]
      ,[Brand]
      ,[Price]
      ,[ExpiryDate]
  FROM [dbo].[ProductMaster]
  WHERE ProductID = @ProductID
END
GO
