-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE ProductOperation
	@ProductID INT,
	@ProductName VARCHAR(100),
	@Brand VARCHAR(100),
	@Price DECIMAL,
	@ExpiryDate DATE,
	@CategoryID INT
AS
BEGIN
	SET NOCOUNT ON;

	IF @ProductID = 0
	BEGIN
	INSERT INTO ProductMaster
	(
		[CategoryID]
        ,[ProductName]
        ,[Brand]
        ,[Price]
        ,[ExpiryDate])
     VALUES
	 (
		@CategoryID,
		@ProductName,
		@Brand,
		@Price,
		@ExpiryDate
	 )

	 SET @ProductID = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE ProductMaster
		SET 
			ProductName = @ProductName,
			Brand = @Brand,
			Price = @Price,
			ExpiryDate = @ExpiryDate,
			CategoryID = @CategoryID
		WHERE
			ProductID = @ProductID
	END

	SELECT @ProductID AS ProductID
END
GO
