
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE GetAllProducts
AS
BEGIN
	SET NOCOUNT ON;

    SELECT [ProductID]
      ,P.[CategoryID]
	  ,C.CategoryName
      ,[ProductName]
      ,[Brand]
      ,[Price]
      ,[ExpiryDate]
  FROM [ProductMaster] P
  INNER JOIN [CategoryMaster] C ON C.CategoryID = P.CategoryID
END
GO
