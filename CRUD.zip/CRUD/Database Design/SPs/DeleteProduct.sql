-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE DeleteProduct
	@ProductID INT
AS
BEGIN
	SET NOCOUNT ON;

    DELETE FROM ProductMaster
	WHERE ProductID = @ProductID

	SELECT @ProductID
END
GO
