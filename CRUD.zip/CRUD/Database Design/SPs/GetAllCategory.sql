-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE GetAllCategory
AS
BEGIN
	SET NOCOUNT ON;

    SELECT [CategoryID]
      ,[CategoryName]
  FROM [dbo].[CategoryMaster]
END
GO
