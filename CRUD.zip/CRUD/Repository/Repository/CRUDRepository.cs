﻿using Entities;
using Entities.Domain;
using Repository.Infrastructure;
using Repository.Repository;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repository
{
    public class CRUDRepository : BaseRepository, ICRUDRepository
    {
        public CRUDRepository(IDatabaseFactory databaseFactory) : base(databaseFactory) { }

        public List<ProductMaster> GetAllProducts()
        {
            try
            {
                return CRUDDatabaseContext.Database.SqlQuery<ProductMaster>("EXEC GetAllProducts").ToList();
            }
            catch (System.Exception)
            {
                throw;
            }
        }

        public List<CategoryMaster> GetAllCategory()
        {
            try
            {
                return CRUDDatabaseContext.Database.SqlQuery<CategoryMaster>("EXEC GetAllCategory").ToList();
            }
            catch (System.Exception)
            {
                throw;
            }
        }

        public int ProductOperation(ProductMaster productMaster)
        {
            try
            {
                return CRUDDatabaseContext.Database.SqlQuery<int>("EXEC ProductOperation @ProductID, @ProductName, @Brand, @Price, @ExpiryDate, @CategoryID",
                                                                        new SqlParameter("@ProductID", productMaster.ProductID),
                                                                        new SqlParameter("@ProductName", productMaster.ProductName),
                                                                        new SqlParameter("@Brand", productMaster.Brand),
                                                                        new SqlParameter("@Price", productMaster.Price),
                                                                        new SqlParameter("@ExpiryDate", productMaster.ExpiryDate),
                                                                        new SqlParameter("@CategoryID", productMaster.CategoryID)).FirstOrDefault();
            }
            catch (System.Exception)
            {
                throw;
            }
        }

        public ProductMaster GetProductByID(int productID)
        {
            try
            {
                return CRUDDatabaseContext.Database.SqlQuery<ProductMaster>("EXEC GetProductByID @ProductID",
                                            new SqlParameter("@ProductID", productID)).FirstOrDefault();
            }
            catch (System.Exception)
            {
                throw;
            }
        }

        public int DeleteProduct(int productID)
        {
            try
            {
                return CRUDDatabaseContext.Database.SqlQuery<int>("EXEC DeleteProduct @ProductID", 
                                                    new SqlParameter("@ProductID", productID)).FirstOrDefault();
            }
            catch (System.Exception)
            {
                throw;
            }
        }
    }
}
