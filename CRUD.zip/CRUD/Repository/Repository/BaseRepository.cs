﻿using Repository.Infrastructure;

namespace Repository.Repository
{
    public class BaseRepository
    {
        private CRUDDatabaseContext _crudDatabaseContext;

        private IDatabaseFactory _DatabaseFactory { get; set; }

        protected BaseRepository(IDatabaseFactory databaseFactory)
        {
            _DatabaseFactory = databaseFactory;
        }

        protected CRUDDatabaseContext CRUDDatabaseContext
        {
            get
            {
                return _crudDatabaseContext ?? (_crudDatabaseContext = _DatabaseFactory.GetContext());
            }
        }
    }
}
