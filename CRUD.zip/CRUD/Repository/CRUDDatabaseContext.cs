﻿using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace Repository
{
    public class CRUDDatabaseContext : DbContext
    {
        public CRUDDatabaseContext() : base("TowingEntities")
        {
            ((IObjectContextAdapter)this).ObjectContext.CommandTimeout = 600;
        }

        public virtual void Commit()
        {
            base.SaveChanges();
        }
    }
}
