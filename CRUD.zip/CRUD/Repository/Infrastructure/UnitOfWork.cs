﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Infrastructure
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDatabaseFactory _databaseFactory;
        private CRUDDatabaseContext _crudDataContext;

        protected CRUDDatabaseContext CRUDDataContext
        {
            get { return _crudDataContext ?? (_crudDataContext = _databaseFactory.GetContext()); }
        }

        public UnitOfWork(IDatabaseFactory databaseFactory)
        {
            _databaseFactory = databaseFactory;
        }

        
        public void Commit()
        {
            CRUDDataContext.Commit();
        }
    }
}
