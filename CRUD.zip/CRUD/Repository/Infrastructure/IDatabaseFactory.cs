﻿using System;

namespace Repository.Infrastructure
{
    public interface IDatabaseFactory
    {
        CRUDDatabaseContext GetContext();
    }
}
