﻿namespace Entities
{
    public interface IUnitOfWork
    {
        void Commit();
    }
}
