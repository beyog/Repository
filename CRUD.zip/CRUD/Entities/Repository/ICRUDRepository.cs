﻿using Entities.Domain;
using System.Collections.Generic;

namespace Entities
{
    public interface ICRUDRepository
    {
        List<ProductMaster> GetAllProducts();

        List<CategoryMaster> GetAllCategory();

        int ProductOperation(ProductMaster productMaster);

        ProductMaster GetProductByID(int productID);

        int DeleteProduct(int productID);
    }
}
