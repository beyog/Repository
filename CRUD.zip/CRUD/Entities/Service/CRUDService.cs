﻿namespace Entities.Service
{
    public class CRUDService
    {
        public IUnitOfWork UnitOfWork;
        public ICRUDRepository CRUDRepository;  

        public CRUDService(IUnitOfWork _unitOfWork,
                            ICRUDRepository _crudRepository)
        {
            UnitOfWork = _unitOfWork;
            CRUDRepository = _crudRepository;
        }
    }
}
