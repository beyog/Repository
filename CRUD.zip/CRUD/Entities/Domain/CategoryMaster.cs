﻿namespace Entities.Domain
{
    public class CategoryMaster
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
    }
}
