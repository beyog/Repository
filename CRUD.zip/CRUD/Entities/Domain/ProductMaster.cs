﻿using System;
using System.Collections.Generic;

namespace Entities.Domain
{
    public class ProductMaster
    {
        public string CategoryName { get; set; }
        public int CategoryID { get; set; }
        public List<CategoryMaster> CategoryMasterList { get; set; }

        public decimal? Price { get; set; }

        public DateTime ExpiryDate { get; set; }

        public string Brand { get; set; }

        public string ProductName { get; set; }

        public int ProductID { get; set; }
    }
}
