﻿using Entities.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CRUD.Models
{
    public class mdlProductMaster
    {
        [Required]
        public int CategoryID { get; set; }
        public List<CategoryMaster> CategoryMasterList { get; set; }

        [Required]
        public decimal? Price { get; set; }

        [Required]
        public string ExpiryDate { get; set; }

        public DateTime dtExpiryDate { get; set; }

        [Required]
        public string Brand { get; set; }

        [Required]
        public string ProductName { get; set; }

        public int ProductID { get; set; }
    }
}