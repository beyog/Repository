﻿using Entities.Service;
using Repository;
using Repository.Infrastructure;
using System.Web.Mvc;

namespace CRUD.Controllers
{
    public class BaseController : Controller
    {
        private CRUDService _crudService;

        protected CRUDService CRUDService
        {
            get
            {
                if (_crudService == null)
                {
                    var databaseFactory = new DatabaseFactory();
                    _crudService = new CRUDService(new UnitOfWork(databaseFactory),
                                                    new CRUDRepository(databaseFactory));
                }

                return _crudService;
            }
        }
    }
}