﻿using CRUD.Models;
using Entities.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace CRUD.Controllers
{
    public class HomeController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Action to render view of add product
        /// </summary>
        /// <returns></returns>
        public ActionResult AddProduct()
        {
            mdlProductMaster model = new mdlProductMaster();

            model.CategoryMasterList = CRUDService.CRUDRepository.GetAllCategory();

            return View("AddProduct", model);
        }

        /// <summary>
        /// Post action to add/edit product
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult AddProduct(mdlProductMaster model)
        {
            if (ModelState.IsValid)
            {
                ProductMaster updateProduct = new ProductMaster();
                updateProduct.Brand = model.Brand;
                updateProduct.CategoryID = model.CategoryID;
                updateProduct.ExpiryDate = Convert.ToDateTime(model.ExpiryDate);
                updateProduct.Price = model.Price;
                updateProduct.ProductID = model.ProductID;
                updateProduct.ProductName = model.ProductName;
                updateProduct.ProductID = CRUDService.CRUDRepository.ProductOperation(updateProduct);

                if (updateProduct.ProductID > 0)
                {
                    return Content("1");
                }
                else
                {
                    return Content("0");
                }
            }
            else
                return Content("0");
        }

        /// <summary>
        /// Action to get all products
        /// </summary>
        /// <returns></returns>
        public JsonResult GetAllProduct()
        {
            List<ProductMaster> allProducts = new List<ProductMaster>();

            allProducts = CRUDService.CRUDRepository.GetAllProducts();
            var result = from c in allProducts
                         select new[] {
                            c.ProductName,
                            c.CategoryName,
                            c.Brand,
                            c.Price.ToString(),
                            c.ExpiryDate.ToShortDateString(),
                             c.ProductID.ToString()};
            return Json(new
            {
                aaData = result,
                iTotalRecords = result.Count(),
                iTotalDisplayRecords = result.Count()
            }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Action to render add product with details
        /// </summary>
        /// <param name="productID"></param>
        /// <returns></returns>
        public ActionResult EditProduct(int productID)
        {
            mdlProductMaster model = new mdlProductMaster();

            ProductMaster product = CRUDService.CRUDRepository.GetProductByID(productID);
            if (product != null)
            {
                model.Brand = product.Brand;
                model.CategoryID = product.CategoryID;
                model.dtExpiryDate = product.ExpiryDate;
                model.Price = product.Price.Value;
                model.ProductName = product.ProductName;
                model.ProductID = product.ProductID;
                model.CategoryMasterList = CRUDService.CRUDRepository.GetAllCategory();
            }

            return PartialView("_AddProduct", model);
        }

        /// <summary>
        /// Action to delete product
        /// </summary>
        /// <param name="productID"></param>
        /// <returns></returns>
        public ActionResult DeleteProduct(int productID)
        {
            List<ProductMaster> allProducts = new List<ProductMaster>();
            productID = CRUDService.CRUDRepository.DeleteProduct(productID);

            if(productID > 0)
            {
                return Content("1");
            }
            else
            {
                return Content("0");
            }
            
        }
    }
}